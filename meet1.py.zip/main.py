print("amar Muhammad asri")
print("asal dari SUMBAWA")
print("kalo malas kuliah ingat orang tua")
print("semoga kuliah 3,5 tahun itu terwujud")